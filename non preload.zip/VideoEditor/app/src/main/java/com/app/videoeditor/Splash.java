package com.app.videoeditor;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;

public class Splash extends AppCompatActivity {
    private Ads ads;
    private boolean isNavigated = false;
    private static final String TAG = "SplashActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        Log.d(TAG, "onCreate: Splash started");

        ads = new Ads(this);
        ads.loadAd();
        Log.d(TAG, "onCreate: Ad loading started");

        // 3 sec fallback
        new Handler().postDelayed(() -> {
            if (!isNavigated) {
                Log.d(TAG, "Handler 3s: Timeout, moving to MainActivity");
                startMainActivity();
            }
        }, 4000);

        // 1 sec baad ad dikhane ki koshish
        new Handler().postDelayed(() -> {
            Log.d(TAG, "Handler 1s: Trying to show ad");
            ads.show(new Ads.AdListener() {
                @Override
                public void onDismissed() {
                    Log.d(TAG, "Ad dismissed, moving to MainActivity");
                    startMainActivity();
                }

                @Override
                public void onFailed() {
                    Log.d(TAG, "Ad failed, moving to MainActivity");
                    startMainActivity();
                }
            });
        }, 4000);
    }

    private void startMainActivity() {
        if (!isNavigated) {
            isNavigated = true;
            Log.d(TAG, "startMainActivity: Navigating to MainActivity");
            Intent intent = new Intent(Splash.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish(); // yeh zaroori hai, warna Splash stack me phansa rahega
        }
    }
}
