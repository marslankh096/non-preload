package com.app.videoeditor;

import android.app.Activity;
import androidx.annotation.NonNull;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

public class Ads {

    private InterstitialAd mInterstitialAd;
    private String adUnitId;
    private Activity activity;

    public Ads(Activity activity) {
        this.activity = activity;
        this.adUnitId = activity.getResources().getString(R.string.InterstitialAd);
    }

    public void loadAd() {
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(activity, adUnitId, adRequest, new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                mInterstitialAd = interstitialAd;
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                mInterstitialAd = null; // sirf null karo, Splash decide karega
            }
        });
    }

    public void show(final AdListener adListener) {
        if (mInterstitialAd != null) {
            mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override
                public void onAdDismissedFullScreenContent() {
                    adListener.onDismissed();
                    mInterstitialAd = null;
                }

                @Override
                public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError adError) {
                    adListener.onFailed();
                }

                @Override
                public void onAdShowedFullScreenContent() {
                    mInterstitialAd = null;
                }
            });
            mInterstitialAd.show(activity);
        } else {
            adListener.onFailed();
        }
    }

    public interface AdListener {
        void onDismissed();
        void onFailed();
    }
}
